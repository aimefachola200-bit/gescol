# -*- coding: utf-8 -*-
"""Référentiel du Bénin : 12 départements (DDEMP) et 118 circonscriptions scolaires (CS)
avec leurs arrondissements et nombre de zones pédagogiques (source : liste officielle fournie)."""

CIRCONSCRIPTIONS = {
 "Alibori": [
  {
   "n": 1,
   "cs": "BANIKOARA 1",
   "arrondissements": "Banikoara Centre, Goumori, Kokiborou, Ounet, Soroko et Toura",
   "zones": 3
  },
  {
   "n": 2,
   "cs": "BANIKOARA 2",
   "arrondissements": "Founougo, Gomparou, Kokey et Sompérékou",
   "zones": 3
  },
  {
   "n": 3,
   "cs": "GOGOUNOU",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 4,
   "cs": "KANDI 1",
   "arrondissements": "Bensékou, Kandi 2, Kandi 3, Kassakou et Sam",
   "zones": 3
  },
  {
   "n": 5,
   "cs": "KANDI 2",
   "arrondissements": "Angaradébou, Donwari, Kandi 1, Saah et Sonsoro",
   "zones": 2
  },
  {
   "n": 6,
   "cs": "KARIMAMA",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 7,
   "cs": "MALANVILLE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 8,
   "cs": "SEGBANA",
   "arrondissements": "",
   "zones": 2
  }
 ],
 "Atacora": [
  {
   "n": 9,
   "cs": "BOUKOUMBE",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 10,
   "cs": "COBLY",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 11,
   "cs": "KEROU",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 12,
   "cs": "KOUANDE",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 13,
   "cs": "MATERI",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 14,
   "cs": "NATITINGOU 1",
   "arrondissements": "Kouandata, Natitingou 3, Perma, Tchoumi-Tchoum, Kotopounga",
   "zones": 3
  },
  {
   "n": 15,
   "cs": "NATITINGOU 2",
   "arrondissements": "Kouaba, Natitingou 1, Natitingou 2 et Pépariyakou",
   "zones": 2
  },
  {
   "n": 16,
   "cs": "PEHUNCO",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 17,
   "cs": "TANGUIETA",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 18,
   "cs": "TOUCOUNTOUNA",
   "arrondissements": "",
   "zones": 2
  }
 ],
 "Atlantique": [
  {
   "n": 19,
   "cs": "ABOMEY-CALAVI 1",
   "arrondissements": "Abomey-Calavi Centre et Akassato",
   "zones": 3
  },
  {
   "n": 20,
   "cs": "ABOMEY-CALAVI 2",
   "arrondissements": "Godomey Est (à la voie inter-États)",
   "zones": 3
  },
  {
   "n": 21,
   "cs": "ABOMEY-CALAVI 3",
   "arrondissements": "Glo-Djigbé, Kparroun et Zinvié",
   "zones": 3
  },
  {
   "n": 22,
   "cs": "ABOMEY-CALAVI 4",
   "arrondissements": "Hêvié",
   "zones": 3
  },
  {
   "n": 23,
   "cs": "ABOMEY-CALAVI 5",
   "arrondissements": "Godomey Ouest (à la voie inter-États)",
   "zones": 3
  },
  {
   "n": 24,
   "cs": "ABOMEY-CALAVI 6",
   "arrondissements": "Ouèdo et Togba",
   "zones": 3
  },
  {
   "n": 25,
   "cs": "ALLADA 1",
   "arrondissements": "Allada, Ahouannanzoun, Atogon, Hinvi, Sékou, Togoudo",
   "zones": 3
  },
  {
   "n": 26,
   "cs": "ALLADA 2",
   "arrondissements": "Agbanou, Avakpa, Ayou, Lissègazoun, Lon-Agonmè, Tokpa-Ava",
   "zones": 2
  },
  {
   "n": 27,
   "cs": "KPOMASSE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 28,
   "cs": "OUIDAH 1",
   "arrondissements": "Gakpé, Djègbadji, Houakpè-Daho, Ouidah 1, Ouidah 2, Ouidah 3, Ouidah 4 et Savi",
   "zones": 2
  },
  {
   "n": 29,
   "cs": "OUIDAH 2",
   "arrondissements": "Avlékété et Pahou",
   "zones": 2
  },
  {
   "n": 30,
   "cs": "SO-AVA",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 31,
   "cs": "TOFFO",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 32,
   "cs": "TORI-BOSSITO",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 33,
   "cs": "ZÈ",
   "arrondissements": "",
   "zones": 4
  }
 ],
 "Borgou": [
  {
   "n": 34,
   "cs": "BEMBEREKE 1",
   "arrondissements": "Bembéréké et Ina",
   "zones": 2
  },
  {
   "n": 35,
   "cs": "BEMBEREKE 2",
   "arrondissements": "Béroubouay, Bouanri et Gamia",
   "zones": 3
  },
  {
   "n": 36,
   "cs": "KALALE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 37,
   "cs": "N’DALI",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 38,
   "cs": "NIKKI",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 39,
   "cs": "PARAKOU 1",
   "arrondissements": "1er Arrondissement",
   "zones": 3
  },
  {
   "n": 40,
   "cs": "PARAKOU 2",
   "arrondissements": "2e Arrondissement",
   "zones": 3
  },
  {
   "n": 41,
   "cs": "PARAKOU 3",
   "arrondissements": "3e Arrondissement",
   "zones": 2
  },
  {
   "n": 42,
   "cs": "PERERE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 43,
   "cs": "SINENDE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 44,
   "cs": "TCHAOUROU 1",
   "arrondissements": "Tchaourou, Tchatchou, Goro",
   "zones": 3
  },
  {
   "n": 45,
   "cs": "TCHAOUROU 2",
   "arrondissements": "Alafiarou, Bétérou, Sasson",
   "zones": 3
  },
  {
   "n": 46,
   "cs": "TCHAOUROU 3",
   "arrondissements": "Kika",
   "zones": 2
  }
 ],
 "Collines": [
  {
   "n": 47,
   "cs": "BANTE",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 48,
   "cs": "DASSA-ZOUMÈ 1",
   "arrondissements": "Dassa 1, Dassa 2, Kéré, Kpingni et Léma",
   "zones": 3
  },
  {
   "n": 49,
   "cs": "DASSA-ZOUMÈ 2",
   "arrondissements": "Akofodjoulè, Gbaffo, Paouignan, Soclogbo et Tré",
   "zones": 2
  },
  {
   "n": 50,
   "cs": "GLAZOUE 1",
   "arrondissements": "Glazoué, Gomè, Kpakpaza, Sokponta et Zaffé",
   "zones": 3
  },
  {
   "n": 51,
   "cs": "GLAZOUE 2",
   "arrondissements": "Aklampa, Assanté, Magoumi, Ouédèmè et Thio",
   "zones": 3
  },
  {
   "n": 52,
   "cs": "OUESSE",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 53,
   "cs": "SAVALOU 1",
   "arrondissements": "Gobada, Kpataba, Lahotan, Logozohè, Monkpa, Savalou-Agbado, Savalou-Attakè",
   "zones": 3
  },
  {
   "n": 54,
   "cs": "SAVALOU 2",
   "arrondissements": "Djaloukovo, Doumè, Savalou-Agah, Léma, Ottoh, Savalou-Ouèssè et Tchetti",
   "zones": 3
  },
  {
   "n": 55,
   "cs": "SAVE",
   "arrondissements": "",
   "zones": 4
  }
 ],
 "Couffo": [
  {
   "n": 56,
   "cs": "APLAHOUE 1",
   "arrondissements": "Aplahoué, Atomèy, Lonkly, Dekpo et Godohou",
   "zones": 2
  },
  {
   "n": 57,
   "cs": "APLAHOUE 2",
   "arrondissements": "Azovè et Kissamèy",
   "zones": 3
  },
  {
   "n": 58,
   "cs": "DJAKOTOMEY 1",
   "arrondissements": "Adjintimè, Djakotomey 1, Gohomey, Kpoba et Sokouhoué",
   "zones": 2
  },
  {
   "n": 59,
   "cs": "DJAKOTOMEY 2",
   "arrondissements": "Djakotomey 2, Bétoumey, Houéganmey, Kinkinhoué et Kokohoué",
   "zones": 2
  },
  {
   "n": 60,
   "cs": "DOGBO",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 61,
   "cs": "KLOUEKANME 1",
   "arrondissements": "Ahogbèya, Ayahohoué, Klouékanmè et Tchikpé",
   "zones": 3
  },
  {
   "n": 62,
   "cs": "KLOUEKANME 2",
   "arrondissements": "Adjahonmè, Détto, Hondjin et Lanta",
   "zones": 3
  },
  {
   "n": 63,
   "cs": "LALO",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 64,
   "cs": "TOVIKLIN",
   "arrondissements": "",
   "zones": 3
  }
 ],
 "Donga": [
  {
   "n": 65,
   "cs": "BASSILA 1",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 66,
   "cs": "BASSILA 2",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 67,
   "cs": "COPARGO",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 68,
   "cs": "DJOUGOU 1",
   "arrondissements": "Bariénou, Bougou, Djougou 1 et Pélébina",
   "zones": 3
  },
  {
   "n": 69,
   "cs": "DJOUGOU 2",
   "arrondissements": "Bariénou, Bélefoungou, Djougou 2 et Kolokondé",
   "zones": 3
  },
  {
   "n": 70,
   "cs": "DJOUGOU 3",
   "arrondissements": "Djougou 3, Onklou, Partago et Sérou",
   "zones": 3
  },
  {
   "n": 71,
   "cs": "OUAKE",
   "arrondissements": "",
   "zones": 3
  }
 ],
 "Littoral": [
  {
   "n": 72,
   "cs": "COTONOU 1",
   "arrondissements": "12e Arrondissement",
   "zones": 3
  },
  {
   "n": 73,
   "cs": "COTONOU 2",
   "arrondissements": "3e Arrondissement et 4e Arrondissement",
   "zones": 3
  },
  {
   "n": 74,
   "cs": "COTONOU 3",
   "arrondissements": "7e Arrondissement, 8e Arrondissement et 9e Arrondissement",
   "zones": 2
  },
  {
   "n": 75,
   "cs": "COTONOU 4",
   "arrondissements": "5e Arrondissement, 6e Arrondissement et 11e Arrondissement",
   "zones": 3
  },
  {
   "n": 76,
   "cs": "COTONOU 5",
   "arrondissements": "1er Arrondissement et 2e Arrondissement",
   "zones": 3
  },
  {
   "n": 77,
   "cs": "COTONOU 6",
   "arrondissements": "10e Arrondissement et 13e Arrondissement",
   "zones": 3
  }
 ],
 "Mono": [
  {
   "n": 78,
   "cs": "ATHIEME",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 79,
   "cs": "BOPA",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 80,
   "cs": "COME",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 81,
   "cs": "GRAND-POPO",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 82,
   "cs": "HOUEYOGBE 1",
   "arrondissements": "Doutou, Houéyogbé, Honhoué et Zoungbonou",
   "zones": 2
  },
  {
   "n": 83,
   "cs": "HOUEYOGBE 2",
   "arrondissements": "Dahè et Sè",
   "zones": 3
  },
  {
   "n": 84,
   "cs": "LOKOSSA 1",
   "arrondissements": "Lokossa et Houin",
   "zones": 2
  },
  {
   "n": 85,
   "cs": "LOKOSSA 2",
   "arrondissements": "Agamé, Koudo et Ouédèmè-Adja",
   "zones": 2
  }
 ],
 "Ouémé": [
  {
   "n": 86,
   "cs": "ADJARRA",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 87,
   "cs": "ADJOHOUN",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 88,
   "cs": "AGUEGUES",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 89,
   "cs": "AKPRO-MISSERETE 1",
   "arrondissements": "Akpro-Missérété, Vakon",
   "zones": 3
  },
  {
   "n": 90,
   "cs": "AKPRO-MISSERETE 2",
   "arrondissements": "Gomé-Sota, Katagon et Zoungbomè",
   "zones": 3
  },
  {
   "n": 91,
   "cs": "AVRANKOU 1",
   "arrondissements": "Avrankou, Djomon, Ghozounmè, Kouti et Sado",
   "zones": 2
  },
  {
   "n": 92,
   "cs": "AVRANKOU 2",
   "arrondissements": "Atchoukpa et Ouanho",
   "zones": 2
  },
  {
   "n": 93,
   "cs": "BONOU",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 94,
   "cs": "DANGBO",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 95,
   "cs": "PORTO-NOVO 1",
   "arrondissements": "3e Arrondissement et 4e Arrondissement",
   "zones": 4
  },
  {
   "n": 96,
   "cs": "PORTO-NOVO 2",
   "arrondissements": "1er Arrondissement et 2e Arrondissement",
   "zones": 4
  },
  {
   "n": 97,
   "cs": "PORTO-NOVO 3",
   "arrondissements": "5e Arrondissement",
   "zones": 3
  },
  {
   "n": 98,
   "cs": "SEME-PODJI 1",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 99,
   "cs": "SEME-PODJI 2",
   "arrondissements": "",
   "zones": 3
  }
 ],
 "Plateau": [
  {
   "n": 100,
   "cs": "ADJA-OUERE",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 101,
   "cs": "IFANGNI",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 102,
   "cs": "KETOU 1",
   "arrondissements": "Adakplamè, Kétou et Kpankou",
   "zones": 3
  },
  {
   "n": 103,
   "cs": "KETOU 2",
   "arrondissements": "Idigny, Odomèta et Okpomèta",
   "zones": 2
  },
  {
   "n": 104,
   "cs": "POBE",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 105,
   "cs": "SAKETE",
   "arrondissements": "",
   "zones": 4
  }
 ],
 "Zou": [
  {
   "n": 106,
   "cs": "ABOMEY",
   "arrondissements": "",
   "zones": 4
  },
  {
   "n": 107,
   "cs": "AGBANGNIZOUN",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 108,
   "cs": "BOHICON 1",
   "arrondissements": "Bohicon 1, Ouassaho et Saclo",
   "zones": 3
  },
  {
   "n": 109,
   "cs": "BOHICON 2",
   "arrondissements": "Bohicon 2, Gnidjazoun et Lissézoun",
   "zones": 3
  },
  {
   "n": 110,
   "cs": "BOHICON 3",
   "arrondissements": "Agongointo, Avogbanna, Passagon et Sodohomè",
   "zones": 3
  },
  {
   "n": 111,
   "cs": "COVE",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 112,
   "cs": "DJIDJA 1",
   "arrondissements": "Agouna, Djidja, Houéto et Monsourou",
   "zones": 3
  },
  {
   "n": 113,
   "cs": "DJIDJA 2",
   "arrondissements": "Agondji, Dan, Gobaix, Mougnon, Oumbègamè, Setto et Zounkon",
   "zones": 3
  },
  {
   "n": 114,
   "cs": "OUINHI",
   "arrondissements": "",
   "zones": 2
  },
  {
   "n": 115,
   "cs": "ZAGNANADO",
   "arrondissements": "",
   "zones": 3
  },
  {
   "n": 116,
   "cs": "ZA-KPOTA 1",
   "arrondissements": "Allahé, Houngomè, Za-Kpota et Za-Tanta",
   "zones": 3
  },
  {
   "n": 117,
   "cs": "ZA-KPOTA 2",
   "arrondissements": "Assanlin, Kpakpamè, Kpozoun et Zèko",
   "zones": 2
  },
  {
   "n": 118,
   "cs": "ZOGBODOMEY",
   "arrondissements": "",
   "zones": 4
  }
 ]
}

DEPARTEMENTS = list(CIRCONSCRIPTIONS.keys())


def cs_du_departement(dep):
    return [c["cs"] for c in CIRCONSCRIPTIONS.get(dep, [])]


def departement_de_cs(cs):
    for d, lst in CIRCONSCRIPTIONS.items():
        if any(c["cs"] == cs for c in lst):
            return d
    return None
