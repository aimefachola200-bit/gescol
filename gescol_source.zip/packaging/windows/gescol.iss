﻿; Inno Setup : fabrique GESCOL-Installation-x.y.z.exe à partir de dist\GESCOL
; Compiler depuis la racine du projet :  iscc /DVersion=1.3.0 packaging\windows\gescol.iss

#ifndef Version
  #define Version "1.3.0"
#endif

[Setup]
AppId={{6C1E2B7A-4F3D-4B7E-9C2A-7D5E3F1A9B20}
AppName=GESCOL
AppVersion={#Version}
AppPublisher=GESCOL – Conception : Maître Aimé FACHE
AppCopyright=Conception : Maître Aimé FACHE
DefaultDirName={autopf}\GESCOL
DefaultGroupName=GESCOL
DisableProgramGroupPage=yes
OutputDir=..\..\dist
OutputBaseFilename=GESCOL-Installation-{#Version}
SetupIconFile=..\..\static\icons\gescol.ico
UninstallDisplayIcon={app}\GESCOL.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "bureau"; Description: "Créer une icône sur le bureau"; GroupDescription: "Raccourcis :"
Name: "demarrage"; Description: "Lancer GESCOL au démarrage de Windows (recommandé pour le PC serveur de l'école)"; GroupDescription: "Démarrage :"; Flags: unchecked
Name: "parefeu"; Description: "Autoriser les tablettes et téléphones du Wi-Fi à se connecter (pare-feu Windows)"; GroupDescription: "Réseau :"

[Files]
Source: "..\..\dist\GESCOL\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\GESCOL"; Filename: "{app}\GESCOL.exe"
Name: "{group}\Dossier des données GESCOL"; Filename: "{userappdata}\GESCOL"
Name: "{group}\Désinstaller GESCOL"; Filename: "{uninstallexe}"
Name: "{autodesktop}\GESCOL"; Filename: "{app}\GESCOL.exe"; Tasks: bureau
Name: "{userstartup}\GESCOL"; Filename: "{app}\GESCOL.exe"; Parameters: "--sans-navigateur"; Tasks: demarrage

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""GESCOL"""; Flags: runhidden; Tasks: parefeu
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""GESCOL"" dir=in action=allow protocol=TCP localport=5000 profile=any"; Flags: runhidden; Tasks: parefeu
Filename: "{app}\GESCOL.exe"; Description: "Lancer GESCOL maintenant"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""GESCOL"""; Flags: runhidden; RunOnceId: "SupprRegleParefeu"

[Messages]
french.FinishedLabel=GESCOL est installé.%n%nVos données sont enregistrées dans le dossier « GESCOL » de votre profil Windows : elles sont conservées si vous désinstallez ou mettez à jour GESCOL.%n%nPremière connexion : admin / admin123.
