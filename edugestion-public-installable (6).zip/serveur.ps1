# Petit serveur local pour EduGestion Public (aucune installation requise sous Windows)
$port = 8765
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$port/")
$l.Start()
$types = @{ ".html"="text/html; charset=utf-8"; ".js"="application/javascript"; ".json"="application/json"; ".webmanifest"="application/manifest+json"; ".png"="image/png"; ".jpg"="image/jpeg"; ".css"="text/css"; ".svg"="image/svg+xml" }
Write-Host "EduGestion Public : http://localhost:$port/"
Write-Host "Laissez cette fenetre ouverte pendant l'utilisation. Fermez-la pour arreter."
Start-Process "http://localhost:$port/"
while ($l.IsListening) {
  $c = $l.GetContext()
  $p = [Uri]::UnescapeDataString($c.Request.Url.LocalPath).TrimStart('/')
  if ($p -eq '') { $p = 'index.html' }
  $f = [IO.Path]::GetFullPath((Join-Path $root $p))
  if ($f.StartsWith($root) -and (Test-Path $f -PathType Leaf)) {
    $b = [IO.File]::ReadAllBytes($f)
    $e = [IO.Path]::GetExtension($f).ToLower()
    if ($types.ContainsKey($e)) { $c.Response.ContentType = $types[$e] } else { $c.Response.ContentType = "application/octet-stream" }
    $c.Response.OutputStream.Write($b, 0, $b.Length)
  } else { $c.Response.StatusCode = 404 }
  $c.Response.Close()
}
