@echo off
title EduGestion Public
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serveur.ps1"
