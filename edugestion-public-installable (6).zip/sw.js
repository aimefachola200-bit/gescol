// Fonctionne hors connexion : tout est mis en cache à la première visite.
const V = "egp-v5";
const FILES = ["./", "./index.html", "./manifest.webmanifest", "./qr.js", "./jszip.min.js", "./m1.js", "./m2.js", "./m3.js", "./m4.js", "./m5.js", "./entete-ministere.jpg", "./icons/icon-192.png", "./icons/icon-512.png"];
self.addEventListener("install", (e) => e.waitUntil(caches.open(V).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener("activate", (e) =>
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== V).map((x) => caches.delete(x)))).then(() => self.clients.claim())));
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then((r) => r || fetch(e.request).then((n) => {
      const copy = n.clone(); caches.open(V).then((c) => c.put(e.request, copy)); return n;
    }).catch(() => caches.match("./index.html")))
  );
});
