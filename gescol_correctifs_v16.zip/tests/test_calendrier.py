# -*- coding: utf-8 -*-
"""Tests du calendrier scolaire et des thèmes d'UP (m_calendrier). Lancer : python3 -m unittest tests.test_calendrier"""
import html as html_mod
import io
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date

RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RACINE)
EDITION = os.environ.get("GESCOL_EDITION_TEST", "publique")
DOSSIER = tempfile.mkdtemp(prefix=f"gescol_cal_{EDITION}_")
os.environ["GESCOL_EDITION"] = EDITION
os.environ["GESCOL_DATA"] = DOSSIER

from app import app  # noqa: E402
import config  # noqa: E402
import m_calendrier as MCAL  # noqa: E402

try:
    import openpyxl
except ImportError:  # pragma: no cover
    openpyxl = None


def txt(r):
    return html_mod.unescape(r.data.decode())


class TestCalendrier(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config["TESTING"] = True
        cls.c = app.test_client()
        from werkzeug.security import generate_password_hash
        with app.app_context():
            from app import ex
            ex("UPDATE utilisateurs SET mdp_hash=?, doit_changer_mdp=0 WHERE identifiant='admin'", (generate_password_hash("admin123"),))
        r = cls.c.post("/login", data={"identifiant": "admin", "mdp": "admin123"}, follow_redirects=False)
        assert r.status_code == 302, r.status_code

    def test_01_dates(self):
        self.assertEqual(MCAL.en_iso("07/09/2026"), "2026-09-07")
        self.assertEqual(MCAL.en_iso("2027-01-04"), "2027-01-04")
        self.assertEqual(MCAL.en_iso(""), "")
        self.assertIsNone(MCAL.en_iso("31/02/2027"))
        self.assertIsNone(MCAL.en_iso("n'importe quoi"))
        self.assertEqual(MCAL.fr_long("2026-09-14"), "lundi 14/09/2026")

    def test_02_donnees_officielles(self):
        cal = MCAL.CALENDRIER_2026_2027
        self.assertEqual(len(cal), 12)
        for _c, _i, d1, d2, _d, _o in cal:
            self.assertLessEqual(d1, d2)
        th = MCAL.themes_officiels()
        self.assertEqual(sum(1 for t in th if t[0] == "maternelle"), 12)
        self.assertEqual(sum(1 for t in th if t[0] == "primaire"), 12)
        self.assertEqual(sum(1 for t in th if t[0] == "conference"), 5)
        self.assertEqual(sum(1 for t in th if t[0] == "formation"), 5)
        self.assertEqual(MCAL._DATES[0], "09/10/2026")
        self.assertEqual(MCAL._DATES[-1], "07/05/2027")

    def test_03_pages_et_prerempli(self):
        for url in ("/synoptique/calendrier", "/synoptique/themes-up", "/synoptique/calendrier/0", "/synoptique/themes-up/0",
                    "/synoptique/calendrier.pdf", "/synoptique/themes-up.pdf", "/synoptique/calendrier.xlsx", "/synoptique/themes-up.xlsx"):
            r = self.c.get(url + ("?annee=2026-2027" if "/0" not in url else ""))
            self.assertEqual(r.status_code, 200, f"{url} -> {r.status_code}")
        html = txt(self.c.get("/synoptique/calendrier?annee=2026-2027"))
        for mot in ("Pré-rentrée scolaire", "lundi 14/09/2026", "Grandes vacances", "Lundi de Pentecôte", "lundi 17/05/2027"):
            self.assertIn(mot, html)
        html = txt(self.c.get("/synoptique/themes-up?annee=2026-2027"))
        for mot in ("Renouvellement des bureaux", "09/10/2026", "La dictée préparée", "Pédagogie Explicite", "Conférences pédagogiques"):
            self.assertIn(mot, html)
        self.assertEqual(self.c.get("/synoptique/calendrier.pdf?annee=2026-2027").data[:4], b"%PDF")
        self.assertEqual(self.c.get("/synoptique/themes-up.pdf?annee=2026-2027").data[:4], b"%PDF")
        self.assertNotIn("Région pédagogique", html)
        # onglets du synoptique
        self.assertIn("Calendrier scolaire", txt(self.c.get("/synoptique")))

    def test_04_calendrier_crud(self):
        r = self.c.post("/synoptique/calendrier/0", data={"annee": "2026-2027", "categorie": "ferie", "intitule": "Fête locale",
                                                         "debut": "12/03/2027", "fin": "12/03/2027"}, follow_redirects=True)
        self.assertIn("Fête locale", txt(r))
        with app.app_context():
            from app import q
            lid = q("SELECT id FROM calendrier_officiel_lignes WHERE intitule='Fête locale'", un=True)["id"]
        r = self.c.post(f"/synoptique/calendrier/{lid}", data={"annee": "2026-2027", "categorie": "ferie", "intitule": "Fête locale 2",
                                                              "debut": "13/03/2027", "fin": "13/03/2027"}, follow_redirects=True)
        self.assertIn("Fête locale 2", txt(r))
        # erreurs : date illisible, fin avant début, intitulé vide
        for data in ({"intitule": "X", "debut": "31/02/2027", "fin": ""}, {"intitule": "X", "debut": "10/03/2027", "fin": "01/03/2027"},
                     {"intitule": "", "debut": "", "fin": ""}):
            self.assertEqual(self.c.post("/synoptique/calendrier/0", data=dict(data, annee="2026-2027")).status_code, 400)
        r = self.c.post(f"/synoptique/calendrier/{lid}/supprimer", follow_redirects=True)
        self.assertNotIn("Fête locale 2", txt(r))
        # année sans prérempli : tableau vide, puis ajout
        self.assertIn("Aucune ligne pour 2028-2029", txt(self.c.get("/synoptique/calendrier?annee=2028-2029")))
        self.c.post("/synoptique/calendrier/0", data={"annee": "2028-2029", "categorie": "periode", "intitule": "Premier trimestre",
                                                      "debut": "14/09/2028", "fin": "15/12/2028"})
        self.assertIn("Premier trimestre", txt(self.c.get("/synoptique/calendrier?annee=2028-2029")))
        self.assertNotIn("Pré-rentrée scolaire", txt(self.c.get("/synoptique/calendrier?annee=2028-2029")))

    def test_05_themes_crud(self):
        r = self.c.post("/synoptique/themes-up/0", data={"annee": "2026-2027", "categorie": "primaire", "numero": "13",
                                                        "theme": "Thème de test", "administration": "12/03/2027"}, follow_redirects=True)
        self.assertIn("Thème de test", txt(r))
        with app.app_context():
            from app import q
            tid = q("SELECT id FROM themes_up_lignes WHERE theme='Thème de test'", un=True)["id"]
        self.c.post(f"/synoptique/themes-up/{tid}", data={"annee": "2026-2027", "categorie": "primaire", "theme": "Thème de test 2",
                                                         "administration": "PM"})
        self.assertIn("Thème de test 2", txt(self.c.get("/synoptique/themes-up?annee=2026-2027")))
        self.assertEqual(self.c.post("/synoptique/themes-up/0", data={"annee": "2026-2027", "theme": ""}).status_code, 400)
        self.c.post(f"/synoptique/themes-up/{tid}/supprimer")
        self.assertNotIn("Thème de test 2", txt(self.c.get("/synoptique/themes-up?annee=2026-2027")))

    def test_06_reinitialiser(self):
        self.c.post("/synoptique/calendrier/reinitialiser?annee=2026-2027")
        with app.app_context():
            from app import q
            n = q("SELECT COUNT(*) n FROM calendrier_officiel_lignes WHERE annee='2026-2027'", un=True)["n"]
        self.assertEqual(n, 12)
        self.c.post("/synoptique/themes-up/reinitialiser?annee=2026-2027")
        with app.app_context():
            from app import q
            n = q("SELECT COUNT(*) n FROM themes_up_lignes WHERE annee='2026-2027'", un=True)["n"]
        self.assertEqual(n, 34)

    @unittest.skipIf(openpyxl is None, "openpyxl absent")
    def test_07_excel_aller_retour(self):
        self.c.post("/synoptique/calendrier/reinitialiser?annee=2027-2028")          # tableau vide
        r = self.c.get("/synoptique/calendrier.xlsx?annee=2026-2027")
        wb = openpyxl.load_workbook(io.BytesIO(r.data))
        ws = wb.active
        lignes = [[c.value for c in row] for row in ws.iter_rows()]
        self.assertTrue(any(l and "Pré-rentrée scolaire" in [str(x) for x in l] for l in lignes))
        r = self.c.post("/synoptique/calendrier/import?annee=2027-2028", data={"fichier": (io.BytesIO(r.data), "cal.xlsx")},
                        content_type="multipart/form-data", follow_redirects=True)
        self.assertIn("Import terminé : 12 ligne(s)", txt(r))
        self.assertIn("Grandes vacances", txt(self.c.get("/synoptique/calendrier?annee=2027-2028")))
        r = self.c.get("/synoptique/themes-up.xlsx?annee=2026-2027")
        r = self.c.post("/synoptique/themes-up/import?annee=2027-2028", data={"fichier": (io.BytesIO(r.data), "up.xlsx")},
                        content_type="multipart/form-data", follow_redirects=True)
        self.assertIn("Import terminé : 34 thème(s)", txt(r))
        bad = self.c.post("/synoptique/calendrier/import?annee=2027-2028", data={"fichier": (io.BytesIO(b"pas un xlsx"), "x.xlsx")},
                          content_type="multipart/form-data", follow_redirects=True)
        self.assertIn("illisible", txt(bad))

    def test_08_fonctions_partagees(self):
        with app.test_request_context():
            pass
        import app as A
        self.assertTrue(callable(getattr(A.H, "calendrier_officiel", None)) if hasattr(A, "H") else True)

    def test_09_droits_ecriture(self):
        c2 = app.test_client()
        self.assertEqual(c2.get("/synoptique/calendrier").status_code, 302)           # non connecté -> login
        self.assertEqual(c2.post("/synoptique/calendrier/0", data={"intitule": "X"}).status_code, 302)


if __name__ == "__main__":
    unittest.main()
